// Placeholder JS
console.log("One Drop Soru loaded");